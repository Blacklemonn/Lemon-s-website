﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Manager : MonoBehaviour {

	public int Count;		//떨어지는 박스 세기;
	public float _time;		//박스가 떨어지기까지 걸리는 시간재기.
	bool End;				//박스가 다 떨어졌는지 체크하기.
	public Text Text_time; //시간 표기를 위한 GUIText
	public GameObject ClearGUI;
	public GameObject FailGUI;

	void OnTriggerEnter(Collider Get){

		//부딪힌 오브젝트의 태그가 Box인 경우 Count를 1씩 증가시킨다.
		if (Get.tag=="Box") {
			Count += 1;
			Destroy (Get.gameObject);
		}
       

		//부딪힌 오브젝트의 태그가 Player인 경우 End를 활성화시킨다.
		if (Get.GetComponent<Collider>().tag == "Player" && End == false) {
			End = true;
			FailGUI.SetActive (true);
			GetComponent<GameEndScript> ().endGame (false);

		}

		if (Count >= 36) {
			End = true;
			ClearGUI.SetActive (true);
			GetComponent<GameEndScript> ().endGame (true);

		}
	}
	void Update(){
		//끝나지않은 상태라면 시간을 계속 더해준다.
		if(End==false){
			_time += Time.deltaTime;
		}

		print (_time);

		//_time의 값을 GUIText의 글씨에 표기해준다.
		Text_time.text=_time.ToString("F2");
	}
}