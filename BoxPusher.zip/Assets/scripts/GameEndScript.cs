﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameEndScript : MonoBehaviour {

	//UI objects
	public GameObject endGroup;
	public Text endText;

	//Text Messages
	string winText="Yaaaaaeeeeeh!!";
	string loseText = "You lose.";


	public void endGame(bool isWon)
	{
		//check if player won
		if (isWon)
			endText.text = winText;
		else
			endText.text = loseText;

		//show the dark background and botton
		endGroup.SetActive(true);

	}

	public string FirstGame;

	public void RestartLevel()
	{
		//put my name of scence here

		Application.LoadLevel("123");
	}
		

}
