﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class R_Move : MonoBehaviour {

    public Rigidbody Enemy;
    bool End;
    public GameObject FailGUI;
    public GameObject _target;
    Vector3 lookDirection;


    void Start () {
        StartCoroutine(MoveObject());
	}

    IEnumerator MoveObject()
    {
        Enemy = GetComponent<Rigidbody>();

        while(true)
        {

            float dir1 = Random.Range(-10f, 10f);
            float dir2 = Random.Range(-10f, 10f);

            yield return new WaitForSeconds(1);

            Enemy.velocity = new Vector3(dir1, 2, dir2);
        }
    }

    void OnCollisionEnter(Collision get)
    {
        //부딪힌 오브젝트의 태그가 Player인 경우 End를 활성화시킨다.
        if (get.collider.tag == "Player" && End == false)
        {
            End = true;
            FailGUI.SetActive(true);
            GetComponent<GameEndScript>().endGame(false);

        }
    }
}
