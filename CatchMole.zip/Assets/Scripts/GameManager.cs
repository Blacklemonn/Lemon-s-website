﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public enum GameState
{
    Ready,
    Play,
    End,
    Pause
}

public class GameManager : MonoBehaviour
{

    public GameState GS;                //게임매니져의 상태관리.

    public Hole H;
    public Hole[] Holes;
    public float LimitTime;             //게임 제한시간.
    public Text TimeText;            //게임 제한시간을 표기하기 위한GUIText.

    public int Count_Bad;               //나쁜두더지를 잡은 횟수.
    public int Count_Good;              //착한 두더지를 잡은 횟수.
    public int Count_Bomb;

    public GameObject FinishGame_Group;        //결과화면을 보여주기 위한 오브젝트.
    public GameObject Bomb_Active;
    public Text Final_Count_Bad;     //결과화면에서 나쁜 두더지를 잡은 숫자를 보여 줄 GUIText.
    public Text Final_Count_Good;    //결과화면에서 착한 두더지를 잡은 숫자를 보여 줄 GUIText.
	public Text Final_Count_Bomb;
    public Text Final_Score;         //결과화면에서 착한 두더지를 잡은 숫자를 보여 줄 GUIText.

    public AudioClip ReadySound;        //레디...하는 경우에 플레이 할 사운드.
    public AudioClip GoSound;           //고! 하 는경우에 플레이 할 사운드.
    public AudioClip FinishSound;       //끝나고 결과화면이 나올 경우에 플레이 할 사운드.

    AudioSource audioSource;

    public Image endBG;

    public Text PauseText;

    public Text dieText;

    public float shakeTimer;
    public float shakeAmount;

    public perlinShake PS;

    void Start()
    {
        //Audio Component 변수를 정의한다.
        audioSource = GetComponent<AudioSource>();
        audioSource.clip = ReadySound;
        audioSource.Play();
    }


    public void GO()
    {

        //Start the game, and play a sound.
        GS = GameState.Play;
        audioSource.clip = GoSound;
        audioSource.Play();
    }
    void InsertRank(int Final_Score)
    {
        for (int i = 0; i < 5; i++)
        {
            if (Final_Score > PlayerPrefs.GetInt(i.ToString()))
            {
                for (int j = 4 - i; j > 0; j--)
                {
                    PlayerPrefs.SetInt(j.ToString(), PlayerPrefs.GetInt((j - 1).ToString()));
                    //스코어가 1등 기준으로
                    //playerPrefs의 Key값(j위치의 값 4(5등의 값))을 j-1위치의 값(4등의 값)으로 바꾼다.
                    //j가 1씩 줄어들면서 4등의 값을 3등의 값으로 바꾸어 나아간다.
                }
                PlayerPrefs.SetInt(i.ToString(), Final_Score);//현재 등수를 현재 스코어값으로 바꾸어준다.
                break;
            }
        }
    }

    void Update()
    {
        
        //If game is ready, count the time.
        if (GS == GameState.Play)
        {
            LimitTime -= Time.deltaTime;
            if (LimitTime <= 0)
            {
                LimitTime = 0;
                //게임이 끝나는 시점.
                End();
            }
        }

        //Update the timeText.
        TimeText.text = string.Format("{0:N2}", LimitTime);
    }

    



public void End()
    {

        GS = GameState.End;
        Final_Count_Bad.text = Count_Bad.ToString();
        Final_Count_Good.text = Count_Good.ToString();
		Final_Count_Bomb.text = Count_Bomb.ToString();

        int FScore = (Count_Bad * 100 - Count_Good * 1000+ Count_Bomb * 1000);
        Final_Score.text = FScore.ToString();
        StartCoroutine(fadeIn_Menu(1f));
        //FinishGame_Group.gameObject.SetActive(true);
        audioSource.clip = FinishSound;
        audioSource.Play();
        InsertRank(FScore);
    }

    public void restartGame()
    {
        Application.LoadLevel(Application.loadedLevelName);
    }

    public void Pause()
    {
        Time.timeScale = Time.timeScale == 0 ? 1 : 0;
        if (Time.timeScale==0)
        {
            PauseText.text = "Continue";
            //H.Catch_On and H.Catch_ing make not work
            foreach (Hole myHole in Holes)
                myHole.gameObject.GetComponent<Collider>().enabled = false;
        }
        else
        {
            PauseText.text = "Pause";
            //H.Catch_On and H.Catch_ing make work
            foreach (Hole myHole in Holes)
                myHole.gameObject.GetComponent<Collider>().enabled = true;
        }
    }



    IEnumerator fadeIn_Menu(float fadeTime)
    {
        FinishGame_Group.SetActive(true);
        CanvasGroup menuCanvas = FinishGame_Group.GetComponent<CanvasGroup>();

        float t = 0;

        while (t < fadeTime)
        {
            t += Time.deltaTime;
            float blend = Mathf.Clamp(t / fadeTime, 0, 1f);
            menuCanvas.alpha = Mathf.Lerp(0, 1f, blend);
            yield return null;
        }
    }
}