﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Rank : MonoBehaviour {

    //랭킹 텍스트를 가져올 변수
    public Text Ranking;

    //현재 상태들을 저장할 변수
    public bool isRanking = true;

    //랭킹 오브젝트를 참조할 변수
    public GameObject RankingMenu;

    // Use this for initialization
    void Start () {
            Ranking.text =
                "Ranking\n\n" +
                "1." + PlayerPrefs.GetInt("0") + "\n\n" +
                "2." + PlayerPrefs.GetInt("1") + "\n\n" +
                "3." + PlayerPrefs.GetInt("2") + "\n\n" +
                "4." + PlayerPrefs.GetInt("3") + "\n\n" +
                "5." + PlayerPrefs.GetInt("4");
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
